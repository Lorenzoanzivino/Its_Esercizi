// 1.​ Crea un file piatti.js in src ed esporta un array di oggetti. Ogni oggetto deve
// avere id, nome e prezzo.

const piatti = [
  {
    id: 1,
    nome: "Pizza Margherita",
    prezzo: 7.5
  },
  {
    id: 2,
    nome: "Spaghetti alla Carbonara",
    prezzo: 9.0
  },
  {
    id: 3,
    nome: "Lasagna",
    prezzo: 8.5
  },
  {
    id: 4,
    nome: "Risotto ai Funghi",
    prezzo: 10.0
  },
  {
    id: 5,
    nome: "Insalata Caprese",
    prezzo: 6.0
  }
];

export default piatti;