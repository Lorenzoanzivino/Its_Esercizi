let nome = "Mario";
console.log("Ciao " + nome);
