let numero = 100;
console.log("Valore iniziale: " + numero);

numero = 70;
console.log("Nuovo valore: " + numero);
