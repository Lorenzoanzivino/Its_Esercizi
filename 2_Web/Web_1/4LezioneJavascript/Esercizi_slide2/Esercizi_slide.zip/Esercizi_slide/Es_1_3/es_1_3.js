let x = 10;
let y;
y = x;
let z = "Luca";

console.log("Valore di x:", x, ", tipo:", typeof x);
console.log("Valore di y:", y, ", tipo:", typeof y);
console.log("Valore di z:", z, ", tipo:", typeof z);
